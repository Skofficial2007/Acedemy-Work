#include "second.h"
#include <stdio.h>

void Fun1(void)
{
	printf("\n\nFun1 is happening, now!\n\n\n");
}