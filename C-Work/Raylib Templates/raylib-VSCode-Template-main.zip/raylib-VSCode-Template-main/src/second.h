#ifndef SECOND_H_
#define SECOND_H_

void Fun1(void);

#endif